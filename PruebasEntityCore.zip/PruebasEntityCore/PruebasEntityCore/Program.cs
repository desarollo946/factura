using Microsoft.EntityFrameworkCore;
using PruebasEntityCore.Data.Repository;
using PruebasEntityCore.DB;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
//CONEXION
builder.Services.AddDbContext<ContextoDB>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("conexionTest")));
//FIN CONEXION

// INYECCI�N DEL REPOSITORIO
builder.Services.AddScoped<IRepositoryFactura, RepositoryFactura>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Factura}/{action=Index}/{id?}");

app.Run();


//pasos a hacer 
/*
 1.crear el index 
2. importar modelo que use
3.importar repositorios
4.inyectar repositorios
inject Irepository repositorio
 
 */
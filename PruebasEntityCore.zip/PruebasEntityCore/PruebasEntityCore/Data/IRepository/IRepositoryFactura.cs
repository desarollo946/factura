﻿
using PruebasEntityCore.DB;

namespace PruebasEntityCore.Data.Repository
{
    public interface IRepositoryFactura
    {
        public Task<IEnumerable<Factura>> GetFacturaListAsync();
        public Task<Factura> GetFacturaByIdAsync(int id);
        
        public Task<Factura> AddFacturaAsync(Factura factura);
        public Task<Factura> UpdateFacturaAsync(int id, Factura factura);
        public Task DeleteFacturaAsync(int id);
    }
}

﻿using Microsoft.EntityFrameworkCore;
using PruebasEntityCore.DB;

namespace PruebasEntityCore.Data.Repository
{
   
    public class RepositoryFactura : IRepositoryFactura
    {
        private readonly ContextoDB context;

        public RepositoryFactura(ContextoDB _contexto)
        {
            context = _contexto;
        }
        public async Task<Factura> AddFacturaAsync(Factura factura)
        {
            if(factura != null)
            {
                await context.Facturas.AddAsync(factura);
                await context.SaveChangesAsync();
                return factura;
            }
            else
            {
                return new Factura();
            }
        }

        public async Task DeleteFacturaAsync(int id)
        {
            var FacturaBd=await context.Facturas.FindAsync(id);
            if (FacturaBd != null) 
            { 
               context.Facturas.Remove(FacturaBd);
                await context.SaveChangesAsync();
            }
        }

        public async Task<Factura> GetFacturaByIdAsync(int id)
        {
            var FacturaBd = await context.Facturas.FindAsync(id);
            if (FacturaBd != null) {
                return FacturaBd;
            }
            else
            {
                return new Factura();
            }
        }

        public async Task<IEnumerable<Factura>> GetFacturaListAsync()
        {
            return await context.Facturas.ToListAsync();
            
        }

        public async Task<Factura> UpdateFacturaAsync(int id, Factura factura)
        {
            var facturaBd = await context.Facturas.FindAsync(id);

            if (facturaBd != null) {

                facturaBd.Descripcion = factura.Descripcion;
                factura.Cantidad = factura.Cantidad;
                facturaBd.ValorUnitario = factura.ValorUnitario;
                facturaBd.PrecioTotal = factura.PrecioTotal;

                await context.SaveChangesAsync();
                return facturaBd;
            }
            else
            {
                return new Factura();
            }
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using PruebasEntityCore.Data.Repository;
using PruebasEntityCore.DB;

namespace PruebasEntityCore.Controllers
{
    public class FacturaController : Controller
    {
        private readonly IRepositoryFactura servicio;
        public FacturaController(IRepositoryFactura Repositorio)
        {
            servicio=Repositorio;
        }
        public async Task<IActionResult> Index()
        {
            //ViewBag.factura = servicio.GetFacturaByIdAsync(1);
            Factura factura1 =await servicio.GetFacturaByIdAsync(1);
            return View(factura1);
        }


        //listar factura
    }
}

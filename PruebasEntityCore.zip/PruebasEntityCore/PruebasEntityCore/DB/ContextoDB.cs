﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace PruebasEntityCore.DB;

public partial class ContextoDB : DbContext
{
    public ContextoDB()
    {
    }

    public ContextoDB(DbContextOptions<ContextoDB> options)
        : base(options)
    {
    }

    public virtual DbSet<Factura> Facturas { get; set; }

    public virtual DbSet<FacturaDetalle> FacturaDetalles { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Name=conexionTest");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Factura>(entity =>
        {
            entity.HasKey(e => e.FacturaId).HasName("PK__Factura__5C0248052B6E5EE4");

            entity.Property(e => e.Subtotal).HasComputedColumnSql("([Cantidad]*[ValorUnitario])", true);
        });

        modelBuilder.Entity<FacturaDetalle>(entity =>
        {
            entity.HasKey(e => e.FacturaDetalleId).HasName("PK__FacturaD__A9674B1A58EA7642");

            entity.Property(e => e.Subtotal).HasComputedColumnSql("([Cantidad]*[ValorUnitario])", true);

            entity.HasOne(d => d.Factura).WithMany(p => p.FacturaDetalles).HasConstraintName("FK__FacturaDe__Factu__398D8EEE");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

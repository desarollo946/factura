﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace PruebasEntityCore.DB;

[Table("Factura")]
public partial class Factura
{
    [Key]
    [Column("FacturaID")]
    public int FacturaId { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string Descripcion { get; set; } = null!;

    public int Cantidad { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal ValorUnitario { get; set; }

    [Column(TypeName = "decimal(21, 2)")]
    public decimal? Subtotal { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal? PrecioTotal { get; set; }

    [InverseProperty("Factura")]
    public virtual ICollection<FacturaDetalle> FacturaDetalles { get; set; } = new List<FacturaDetalle>();
}

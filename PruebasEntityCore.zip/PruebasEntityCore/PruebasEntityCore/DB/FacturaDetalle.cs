﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace PruebasEntityCore.DB;

[Table("FacturaDetalle")]
public partial class FacturaDetalle
{
    [Key]
    [Column("FacturaDetalleID")]
    public int FacturaDetalleId { get; set; }

    [Column("FacturaID")]
    public int? FacturaId { get; set; }

    [StringLength(255)]
    [Unicode(false)]
    public string ItemDescripcion { get; set; } = null!;

    public int Cantidad { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal ValorUnitario { get; set; }

    [Column(TypeName = "decimal(21, 2)")]
    public decimal? Subtotal { get; set; }

    [ForeignKey("FacturaId")]
    [InverseProperty("FacturaDetalles")]
    public virtual Factura? Factura { get; set; }
}
